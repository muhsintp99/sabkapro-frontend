// assets
import {
    IconDashboard,
    IconUserPlus,
    IconUsers,
    IconBuildingSkyscraper,
    IconBriefcase,
    IconFileText,
    IconVideo,
    IconBell,
    IconCalendarEvent,
    IconCreditCard,
    IconSettings,
    IconCalendar,
    IconUserCheck,
    IconClock,
    IconCurrencyDollar,
    IconKey,
    IconGraph
} from '@tabler/icons-react';

// constants
const icons = {
    IconDashboard,
    IconUserPlus,
    IconUsers,
    IconBuildingSkyscraper,
    IconBriefcase,
    IconFileText,
    IconVideo,
    IconBell,
    IconCalendarEvent,
    IconCreditCard,
    IconSettings,
    IconCalendar,
    IconUserCheck,
    IconClock,
    IconCurrencyDollar,
    IconKey,
    IconGraph
};

// ==============================|| DASHBOARD FULL MENU GROUP ||============================== //

const dashboard = {
    id: 'dashboard',
    type: 'group',
    children: [
        {
            id: 'main-dashboard',
            title: 'Dashboard',
            type: 'item',
            url: '/dashboard',
            icon: icons.IconDashboard,
            breadcrumbs: false
        },
        {
            id: 'statistics',
            title: 'Statistics',
            type: 'item',
            url: '/statistics',
            icon: icons.IconGraph,
            breadcrumbs: false
        },
        {
            id: 'leads',
            title: 'Leads',
            type: 'collapse',
            icon: icons.IconUserPlus,
            children: [
                {
                    id: 'all-leads',
                    title: 'All Leads',
                    type: 'item',
                    url: '/leads'
                },
                {
                    id: 'new-leads',
                    title: 'New / Pending',
                    type: 'item',
                    url: '/leads/new'
                },
                {
                    id: 'follow-up',
                    title: 'Follow-up',
                    type: 'item',
                    url: '/leads/follow-up'
                },
                {
                    id: 'converted',
                    title: 'Converted',
                    type: 'item',
                    url: '/leads/converted'
                }
            ]
        },
        {
            id: 'candidates',
            title: 'Candidates',
            type: 'collapse',
            icon: icons.IconUsers,
            children: [
                {
                    id: 'all-candidates',
                    title: 'All Candidates',
                    type: 'item',
                    url: '/candidates'
                },
                {
                    id: 'procandidate',
                    title: 'Pro',
                    type: 'item',
                    url: '/candidates/procandidate'
                },
                {
                    id: 'freecandidate',
                    title: 'Free',
                    type: 'item',
                    url: '/candidates/freecandidate'
                },
                {
                    id: 'video-resumes',
                    title: 'Video Resumes',
                    type: 'item',
                    url: '/candidates/video'
                },
                {
                    id: 'assign-staff',
                    title: 'Assign to Staff',
                    type: 'item',
                    url: '/candidates/assign'
                }
            ]
        },
        {
            id: 'employers',
            title: 'Employers',
            type: 'collapse',
            icon: icons.IconBuildingSkyscraper,
            children: [
                {
                    id: 'all-employers',
                    title: 'All Employers',
                    type: 'item',
                    url: '/employers'
                },
                {
                    id: 'job-postings',
                    title: 'Job Postings',
                    type: 'item',
                    url: '/employers/jobs'
                },
                {
                    id: 'hiring-status',
                    title: 'Hiring Status',
                    type: 'item',
                    url: '/employers/status'
                }
            ]
        },
        {
            id: 'courses',
            title: 'Courses',
            type: 'collapse',
            icon: icons.IconVideo,
            children: [
                {
                    id: 'manage-videos',
                    title: 'Manage Videos',
                    type: 'item',
                    url: '/courses/videos'
                },
                {
                    id: 'upload-vimeo',
                    title: 'Upload from Vimeo',
                    type: 'item',
                    url: '/courses/vimeo'
                },
                {
                    id: 'assign-candidates',
                    title: 'Assign to Candidates',
                    type: 'item',
                    url: '/courses/assign'
                }
            ]
        },
        {
            id: 'jobs',
            title: 'Jobs',
            type: 'collapse',
            icon: icons.IconBriefcase,
            children: [
                {
                    id: 'all-jobs',
                    title: 'All Jobs',
                    type: 'item',
                    url: '/jobs'
                },
                {
                    id: 'approve-jobs',
                    title: 'Approve Jobs',
                    type: 'item',
                    url: '/jobs/approve'
                },
                {
                    id: 'applications',
                    title: 'Applications',
                    type: 'item',
                    url: '/jobs/applications'
                }
            ]
        },
        {
            id: 'interviews',
            title: 'Interviews',
            type: 'collapse',
            icon: icons.IconCalendarEvent,
            children: [
                {
                    id: 'schedule',
                    title: 'Schedule',
                    type: 'item',
                    url: '/interviews/schedule'
                },
                {
                    id: 'upcoming',
                    title: 'Upcoming',
                    type: 'item',
                    url: '/interviews/upcoming'
                },
                {
                    id: 'history',
                    title: 'History',
                    type: 'item',
                    url: '/interviews/history'
                }
            ]
        },
        {
            id: 'payments',
            title: 'Payments',
            type: 'collapse',
            icon: icons.IconCreditCard,
            children: [
                {
                    id: 'candidate-payments',
                    title: 'Candidate Payments',
                    type: 'item',
                    url: '/payments/candidates'
                },
                {
                    id: 'employer-payments',
                    title: 'Employer Payments',
                    type: 'item',
                    url: '/payments/employers'
                },
                {
                    id: 'invoices',
                    title: 'Invoices',
                    type: 'item',
                    url: '/payments/invoices'
                }
            ]
        },

        {
            id: 'hr',
            title: 'HR',
            type: 'collapse',
            icon: icons.IconUsers,
            children: [
                {
                    id: 'leaves',
                    title: 'Leaves',
                    type: 'collapse',
                    // icon: icons.IconCalendar,
                    children: [
                        {
                            id: 'all-leaves',
                            title: 'All Leaves',
                            type: 'item',
                            url: '/hr/leaves',
                        },
                        {
                            id: 'apply-leave',
                            title: 'Apply Leave',
                            type: 'item',
                            url: '/hr/leaves/apply'
                        },
                        {
                            id: 'leave-policy',
                            title: 'Leave Policy',
                            type: 'item',
                            url: '/hr/leaves/policy'
                        }
                    ]
                },
                {
                    id: 'attendance',
                    title: 'Attendance',
                    type: 'collapse',
                    // icon: icons.IconUserCheck,
                    children: [
                        {
                            id: 'daily-attendance',
                            title: 'Daily Attendance',
                            type: 'item',
                            url: '/hr/attendance/daily'
                        },
                        {
                            id: 'monthly-attendance',
                            title: 'Monthly Report',
                            type: 'item',
                            url: '/hr/attendance/monthly'
                        }
                    ]
                }
            ]
        },

        {
            id: 'notifications',
            title: 'Notifications',
            type: 'collapse',
            icon: icons.IconBell,
            children: [
                {
                    id: 'email-templates',
                    title: 'Email Templates',
                    type: 'item',
                    url: '/notifications/emails'
                },
                {
                    id: 'whatsapp-templates',
                    title: 'WhatsApp Templates',
                    type: 'item',
                    url: '/notifications/whatsapp'
                }
            ]
        },
        // {
        //   id: 'settings',
        //   title: 'Settings',
        //   type: 'collapse',
        //   icon: icons.IconSettings,
        //   children: [
        //     {
        //       id: 'roles-permissions',
        //       title: 'Roles & Permissions',
        //       type: 'item',
        //       url: '/settings/roles'
        //     },
        //     {
        //       id: 'profile-settings',
        //       title: 'Profile Settings',
        //       type: 'item',
        //       url: '/settings/profile'
        //     },
        //     {
        //       id: 'system-settings',
        //       title: 'System Settings',
        //       type: 'item',
        //       url: '/settings/system'
        //     }
        //   ]
        // }
    ]
};

export default dashboard;
